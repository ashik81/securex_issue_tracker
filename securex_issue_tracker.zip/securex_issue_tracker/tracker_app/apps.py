from django.apps import AppConfig


class TrackerAppConfig(AppConfig):
    name = 'tracker_app'
